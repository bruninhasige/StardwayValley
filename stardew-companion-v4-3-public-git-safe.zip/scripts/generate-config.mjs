import fs from 'node:fs';
import { URL } from 'node:url';

const required = ['SUPABASE_URL','SUPABASE_PUBLISHABLE_KEY','TURNSTILE_SITE_KEY'];
const missing = required.filter((name) => !process.env[name]);
if (missing.length) {
  console.error(`Missing required environment variables: ${missing.join(', ')}`);
  process.exit(1);
}

let supabase;
try {
  supabase = new URL(process.env.SUPABASE_URL);
  if (supabase.protocol !== 'https:') throw new Error('SUPABASE_URL must use https');
} catch (error) {
  console.error('Invalid SUPABASE_URL:', error.message);
  process.exit(1);
}

const config = {
  supabaseUrl: process.env.SUPABASE_URL,
  supabasePublishableKey: process.env.SUPABASE_PUBLISHABLE_KEY,
  turnstileSiteKey: process.env.TURNSTILE_SITE_KEY
};
fs.writeFileSync('config.js', `window.APP_CONFIG = ${JSON.stringify(config, null, 2)};\n`);

const template = fs.readFileSync('_headers.template','utf8');
const httpsOrigin = supabase.origin;
const wssOrigin = `wss://${supabase.host}`;
const headers = template
  .replace('__SUPABASE_HTTPS__', httpsOrigin)
  .replace('__SUPABASE_WSS__', wssOrigin);
fs.writeFileSync('_headers', headers);
console.log('Runtime config and security headers generated.');
