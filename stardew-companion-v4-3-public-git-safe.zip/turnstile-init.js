'use strict';
window.turnstileApiReady=false;
window.onTurnstileApiLoad=function(){
  window.turnstileApiReady=true;
  window.dispatchEvent(new Event('turnstile-ready'));
};
