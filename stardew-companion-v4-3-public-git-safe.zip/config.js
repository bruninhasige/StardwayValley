window.APP_CONFIG = {
  supabaseUrl: '',
  supabasePublishableKey: '',
  turnstileSiteKey: ''
};
