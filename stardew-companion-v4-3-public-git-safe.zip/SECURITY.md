# Security Policy

## Secrets

Never commit or expose:

- Supabase service-role/secret keys
- database passwords
- Cloudflare Turnstile Secret Key
- personal access tokens or administrator credentials

Frontend publishable/site keys are intentionally client-side values and can be inspected by visitors after deployment. Keep authorization enforced with Supabase Row Level Security (RLS).

## Authentication

The application uses Supabase Auth and Cloudflare Turnstile. Passwords are handled by Supabase Auth and are not stored in the app's local progress table.

## Reporting

If this repository is made public, use the repository's private security-reporting feature rather than opening an issue containing credentials or vulnerability details.
