# Stardew Valley Companion — v4.3

Projeto fan-made em HTML, CSS e JavaScript para acompanhar calendário, pesca, missões, projetos, Centro Comunitário, relacionamentos, receitas, correio e conquistas.

> Projeto independente, não afiliado à ConcernedApe, Chucklefish ou aos detentores da marca Stardew Valley.

## Segurança e configuração

Nenhuma credencial privada deve ser versionada. O repositório contém apenas `config.js` vazio e `.env.example` com nomes das variáveis.

Para deploy no Netlify, configure em **Site configuration → Environment variables**:

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `TURNSTILE_SITE_KEY`

O build executa `scripts/generate-config.mjs`, que gera `config.js` e `_headers` apenas no ambiente de deploy.

### Nunca publique

- Supabase `service_role` / secret key
- senha do banco de dados
- Cloudflare Turnstile Secret Key
- tokens pessoais, senhas ou chaves administrativas

A `SUPABASE_PUBLISHABLE_KEY` e a Turnstile Site Key são credenciais de cliente e ficam visíveis no navegador quando o site está publicado. A segurança dos dados depende de RLS no Supabase e da Secret Key do Turnstile permanecer somente no serviço autorizado. Mantê-las fora do Git reduz exposição no código-fonte, mas não as transforma em segredos.

## Rodar localmente sem autenticação

Abra o site por um servidor estático. Sem configuração, o Companion continua funcionando em modo visitante com `localStorage`; login e sincronização ficam desabilitados.

## Deploy no Netlify

1. Conecte o repositório ao Netlify.
2. Cadastre as três variáveis acima no ambiente `Production`.
3. Use o comando de build `npm run build` e diretório de publicação `.` (o `netlify.toml` já contém isso).
4. Faça o deploy.

## Stack

HTML + CSS + JavaScript puro, Supabase Auth/Postgres, Cloudflare Turnstile e Netlify.
